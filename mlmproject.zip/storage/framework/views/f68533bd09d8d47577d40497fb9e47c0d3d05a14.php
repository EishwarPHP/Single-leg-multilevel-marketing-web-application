
<?php $__env->startSection('title'); ?>
    User Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">All Users List </h4>
                        <p class="category">All Register Users List Showing here</p>
                    </div>
                    <div class="content">
                        <table border="1" bordercolor="#ccc" class="table table-striped">
                                <tr class="">
                                    <th>#</th>
                                    <th>FullName</th>
                                    <th>Mobile</th>
                                    <th>EmailID</th>
                                    <th>E-Pin</th>
                                    <th>ReferralKey</th>
                                    <th>SponserID</th>
                                    
                                </tr>
                                <?php $__currentLoopData = $treeviewList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $tuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td><a href="../<?php echo e('treeview'); ?>/<?php echo e($tuser->referralkey); ?>"><?php echo e($tuser->name); ?></a></td>
                                    <td><?php echo e($tuser->mobile); ?></td>
                                    <td><?php echo e($tuser->email); ?></td>
                                    <td><?php echo e($tuser->epin); ?></td>
                                    <td><?php echo e($tuser->referralkey); ?></td>
                                    <td><?php echo e($tuser->sponserid); ?></td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <div><?php echo e($treeviewList->links()); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutes.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/treeview.blade.php ENDPATH**/ ?>