
<?php $__env->startSection('title'); ?>
    Report
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Direct Outcome Reports</h4>
                        <p class="category">Outgoing Level Direct Outcome Report</p>
                    </div>
                    <div class="content">
                        <form action="<?php echo e(route('directoutcome')); ?>" method="POST">
                            <?php echo e(method_field('post')); ?>

                            <?php echo csrf_field(); ?>
                            
                            <input type="date" name="datepicker_from" >
                            <input type="date" name="datepicker_to" >
                            <input type="submit" name="submit" value="Search">
                        </form>
                    </div>
                </div>
            </div>
           
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">All Result </h4>
                        <p class="category">All Users List who have my Downline</p>
                    </div>
                    <div class="content">
                        <table border="1" bordercolor="#ccc" class="table table-striped">
                                <tr class="">
                                    <th>#</th>
                                    <th>FullName</th>
                                    <th>ReferralKey</th>
                                    <th>Amount</th>
                                    <th>CreatedAt</th>
                                    
                                </tr>
                                
                                <?php $__currentLoopData = $outcomeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $ouser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td><a href="<?php echo e('treeview'); ?>/<?php echo e($ouser->referralkey); ?>"><?php echo e($ouser->name); ?></a></td>
                                    <td><?php echo e($ouser->referralkey); ?></td>
                                    
                                    <td style="color: green"><b><i class="fa fa-rupee"></i> <?php echo e($ouser->amount); ?></b></td>
                                    <td><?php echo e($ouser->created_at); ?></td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr><th colspan="3">SubTotal</th><th><i class="fa fa-rupee"></i> <?php echo e($comino); ?></th></tr>
                        </table>
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layoutes.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/directoutcome.blade.php ENDPATH**/ ?>