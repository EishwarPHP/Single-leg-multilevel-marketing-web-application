
<?php $__env->startSection('title'); ?>
    User Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">All Users List </h4>
                        <p class="category">All Register Users List Showing here</p>
                    </div>
                    <div class="content">
                        <ul>
                            <?php if(count($itemsres) > 0): ?>
                                <?php $__currentLoopData = $itemsres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li style="background:#ddd;padding:5px 10px;border:1px solid #fff;"><a href="<?php echo e('treeview'); ?>/<?php echo e($item->referralkey); ?>"><?php echo e($item->name); ?></a> | <?php echo e($item->referralkey); ?></li>
                                    <ul>
                                        <?php if(count($item->childItems)): ?>
                                            <?php $__currentLoopData = $item->childItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo $__env->make('sub_items', ['sub_items' => $childItems], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutes.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/alluserslist.blade.php ENDPATH**/ ?>