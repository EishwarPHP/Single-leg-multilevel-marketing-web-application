
<?php $__env->startSection('title'); ?>
    Level Setting
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Requested Status for E-pin</h4>
                        
                    </div>
                    <div class="content">
                            <div class="card table-responsive">
                                <table border="1" bordercolor="#ccc" class="table table-striped">
                                <tr class="">
                                    <th>#</th>
                                    <th>UserId</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Option</th>
                                </tr>
                                <?php $__currentLoopData = $empinList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $pinres): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td><?php echo e($pinres->userid); ?></td>
                                    <td><?php echo e($pinres->amount); ?> </td>
                                    <td><?php echo e($pinres->status); ?> </td>
                                    <td><?php echo e(date('d-m-y', strtotime($pinres->created_at))); ?></td>
                                    <td>
                                        <?php if($pinres->status=='Close'): ?>
                                        Expired
                                        <?php else: ?>
                                            
                                        <form action="<?php echo e(route('sendEpinsend')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>  
                                            <input type="hidden" name="user_id" value="<?php echo e($pinres->userid); ?>">
                                            <input type="hidden" name="status" value="Open">
                                            <input type="text" name="pinqty" value="" placeholder="PinQty" style="width: 70px">
                                            <input type="submit" name="send" value="Send">
                                        </form>
                                    <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                            <div><?php echo e($empinList->links()); ?></div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutes.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/epinRequested.blade.php ENDPATH**/ ?>