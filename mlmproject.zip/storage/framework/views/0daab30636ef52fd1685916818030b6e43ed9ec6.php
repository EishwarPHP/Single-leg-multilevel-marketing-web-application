
<li style="background:#eee;padding:5px 10px;border:1px solid #fff;">
    <a href="<?php echo e('treeview'); ?>/<?php echo e($sub_items->referralkey); ?>"><?php echo e($sub_items->name); ?> </a> | <?php echo e($sub_items->referralkey); ?></li>
<?php if($sub_items->itemsFuction): ?>
    <ul>
        <?php if(count($sub_items->itemsFuction) > 0): ?>
            <?php $__currentLoopData = $sub_items->itemsFuction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('sub_items', ['sub_items' => $childItems], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ul>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/sub_items.blade.php ENDPATH**/ ?>