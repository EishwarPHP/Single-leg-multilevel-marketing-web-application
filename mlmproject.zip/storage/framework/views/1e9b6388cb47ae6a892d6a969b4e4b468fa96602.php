<div class="sidebar" data-background-color="white" data-active-color="danger">
  
  <div class="sidebar-wrapper">
        <div class="logo">
            <a href="" class="simple-text">
                Admin Panel
            </a>
        </div>

        <ul class="nav">
        
            <li class="<?php echo e(Request::is('index') ? 'active' : ''); ?>">
                <a href="../<?php echo e('index'); ?>">
                    <i class="fa fa-tachometer"></i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('users') ? 'active' : ''); ?>">
                <a href="../<?php echo e('users'); ?>">
                    <i class="fa fa-share-alt"></i>
                    <p>My Downline</p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('alluserslist') ? 'active' : ''); ?>">
                
                <a href="../<?php echo e('alluserslist'); ?>">
                    <i class="fa fa-users"></i>
                    <p>All Users List</p>
                </a>
            </li>
            
            <li  class="<?php echo e(Request::is('levelSetting') ? 'active' : ''); ?>">
                <a href="../<?php echo e('levelSetting'); ?>">
                    <i class="fa fa-link "></i>
                    <p>Level Setting</p>
                </a>
            </li>
            
            <li class="<?php echo e(Request::is('epinRequested') ? 'active' : ''); ?>">
                <a href="../<?php echo e('epinRequested'); ?>">
                    <i class="fa fa-credit-card"></i>
                    <p>Requested E-pin</p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('epinOrder') ? 'active' : ''); ?>">
                <a href="../<?php echo e('epinOrder'); ?>">
                    <i class="fa fa-shopping-cart"></i>
                    <p>Buy E-pin</p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('myepin') ? 'active' : ''); ?>">
                <a href="../<?php echo e('myepin'); ?>">
                    <i class="fa fa-credit-card"></i>
                    <p>My E-pin</p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('income') ? 'active' : ''); ?>">
                <a href="../<?php echo e('income'); ?>">
                    <i class="fa fa-rupee"></i>
                    <p>My Level Income</p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('directincome') ? 'active' : ''); ?>">
                <a href="../<?php echo e('directincome'); ?>">
                    <i class="fa fa-rupee"></i>
                    <p>My Direct Income</p>
                </a>
            </li>
            <li>
                <a href="#">
                    <i class="fa fa-caret-down"></i>
                    <p>Report Section </p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('reports') ? 'active' : ''); ?>">
                <a href="../<?php echo e('reports'); ?>">
                    <i class="fa fa-rupee"></i>
                    <p>Level Outcome </p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('directoutcome') ? 'active' : ''); ?>">
                <a href="../<?php echo e('directoutcome'); ?>">
                    <i class="fa fa-rupee"></i>
                    <p>Direct Outcome </p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('comincome') ? 'active' : ''); ?>">
                <a href="../<?php echo e('comincome'); ?>">
                    <i class="fa fa-rupee"></i>
                    <p>Total Company Income </p>
                </a>
            </li>
            
            
            
        </ul>
  </div>
</div><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/layoutes/sidebar.blade.php ENDPATH**/ ?>