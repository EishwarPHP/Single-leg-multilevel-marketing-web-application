<ul>
    <?php if(count($usersList) > 0): ?>
        <?php $__currentLoopData = $usersList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($user->name); ?></li>
            <ul>
                <?php if(count($user->allusersList)): ?>
                    <?php $__currentLoopData = $user->allusersList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allusersList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('childrecursive', ['childrecursive' => $allusersList], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</ul><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/recursion.blade.php ENDPATH**/ ?>