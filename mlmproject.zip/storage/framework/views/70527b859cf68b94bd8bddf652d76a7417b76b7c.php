
<?php $__env->startSection('title'); ?>
    Income List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Direct Income List</h4>
                        
                    </div>
                    <div class="content">
                            <div class="table-responsive">
                                <table border="1" bordercolor="#ccc" class="table table-striped">
                                <tr class="">
                                    <th>#</th>
                                    <th>UserId</th>
                                    <th>Income</th>
                                    
                                    <th>UpdatedAt</th>
                                    
                                </tr>
                                <?php $__currentLoopData = $incomeRes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td><?php echo e($result->userref); ?></td>
                                    
                                    <td style="color: green"><b><i class="fa fa-rupee"></i> <?php echo e($result->amount); ?></b></td>
                                    
                                    <td><?php echo e($result->updated_at); ?></td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                            <div><?php echo e($incomeRes->links()); ?></div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutes.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/directincome.blade.php ENDPATH**/ ?>