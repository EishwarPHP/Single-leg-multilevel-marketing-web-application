
<?php $__env->startSection('title'); ?>
    Level Setting
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            
            <div class="col-md-6">
                <div class="card ">
                    <div class="header">
                        <h4 class="title">Add Level Commision</h4>
                        
                    </div>
                    <div class="content">
                        <div class="card table-responsive">
                            <form action="<?php echo e(route('levelSettingo')); ?>" method="POST">
                            <?php echo csrf_field(); ?>  
                                <div class="col-lg-12 col-sm-12">
                                    <label>Level</label><label style="margin-left:200px;">BONUS SETTINGS (in %)</label><br>
                                </div>
                                <div class="col-lg-12 col-sm-12">
                                    
                                    <input type="text" name="level" id="level" class="btn btn-success" value="Level ">
                                    <input type="text" name="commision" id="commision" class="btn btn-success">
                                    <input type="submit" value="Create Level" class="btn btn-success" >
                                </div>                                  
                                
                                
                            </form>
                        </div>

                        <div class="footer">
                            <div class="chart-legend">
                                
                            </div>
                            <hr>
                            <div class="stats">
                                <i class="ti-check"></i> .
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Levels List</h4>
                        
                    </div>
                    <div class="content">
                        
                            <div class="card table-responsive">
                                <table border="1" bordercolor="#ccc" class="table table-striped">
                                <tr class="">
                                    <th>#</th>
                                    <th>Level</th>
                                    <th>Commision</th>
                                    <th>CreatedAt</th>
                                    <th>UpdatedAt</th>
                                    <th>Option</th>
                                </tr>
                                <?php $__currentLoopData = $levelsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $levels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td><?php echo e($levels->level); ?></td>
                                    <td><?php echo e($levels->commision); ?> %</td>
                                    <td><?php echo e($levels->created_at); ?></td>
                                    <td><?php echo e($levels->updated_at); ?></td>
                                    <td><a href="<?php echo e('levelSetting'); ?>">Update</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>

                        
                    
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutes.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/levelSetting.blade.php ENDPATH**/ ?>