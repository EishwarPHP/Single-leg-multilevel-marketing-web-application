<!DOCTYPE html>
<html>
<head>
    <title>Custom Auth in Laravel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body style="margin-top:10%">
    <?php echo $__env->yieldContent('content'); ?>

</body>

</html><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/auth/header.blade.php ENDPATH**/ ?>