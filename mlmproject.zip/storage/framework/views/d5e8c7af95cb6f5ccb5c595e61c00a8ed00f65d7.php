
<?php $__env->startSection('title'); ?>
    Level Setting
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <?php $__currentLoopData = $myprofiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mypro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="card">
                    <div class="header">
                        <h4 class="title">My Profile</h4>
                        
                    </div>
                    <div class="content">
                            <div class="card table-responsive">
                                <table border="1" bordercolor="#ccc" class="table table-striped">
                                
                                    <tr><th>Name</th><td><?php echo e($mypro->name); ?> </td></tr>
                                    <tr><th>Referralkey</th><td><?php echo e($mypro->referralkey); ?></td></tr>
                                    <tr><th>Email</th><td><?php echo e($mypro->email); ?></td></tr>
                                    <tr><th>Mobile</th><td><?php echo e($mypro->mobile); ?> </td></tr>
                                    <tr><th>Sponser Id</th><td><?php echo e($mypro->sponserid); ?> </td></tr>
                                    <tr><th>Password</th><td><?php echo e(session('password')); ?> </td></tr>
                                    <tr><th>E-Pin</th><td><?php echo e($mypro->epin); ?> </td></tr>
                                               
                                </table>
                            </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card ">
                    <div class="header">
                        <h4 class="title">Profile Updation</h4>
                        
                    </div>
                    <div class="content">
                        <form action="<?php echo e(route('updateMyprofile')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                                <label>Name</label>
                                <input type="text" placeholder="Name" id="name" class="form-control" name="name" value="<?php echo e($mypro->name); ?>"
                                    required autofocus >
                                <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                                <label>Mobile Number</label>
                                <input type="text" placeholder="Mobile Number" id="mobile" class="form-control" name="mobile" value="<?php echo e($mypro->mobile); ?>"
                                    required autofocus>
                                <?php if($errors->has('mobile')): ?>
                                <span class="text-danger"><?php echo e($errors->first('mobile')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group mb-3">
                                <label>Password</label>
                                <input type="text" placeholder="Password" id="password" class="form-control"
                                    name="password" value="<?php echo e(session('password')); ?>" required>
                                <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="d-grid mx-auto">
                                <button type="submit" class="btn btn-dark btn-block">Update Now</button>
                            </div>
                            <br>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutes.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/profile.blade.php ENDPATH**/ ?>