
<?php $__env->startSection('title'); ?>
    Level Setting
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                     
                        <h4 class="title">Request E-Pin</h4>
                        
                    </div>
                    <div class="content">
                        <div class="col-lg-12 col-sm-12">
                            <div class="card table-responsive">
                                <form action="<?php echo e(route('requestEpin')); ?>" method="POST">
                                <?php echo csrf_field(); ?>  
                                    <div class="col-lg-12 col-sm-12">
                                        <label>Enter Amount</label><br>
                                    </div>
                                    <div class="col-lg-12 col-sm-12">
                                        <input type="hidden" name="userid" id="userid" class="btn btn-warning" value="<?php echo e(session('email')); ?>">
                                        <input type="text" name="amount" id="amount" class="btn btn-warning" placeholder="Enter Amount">
                                        <input type="hidden" name="status" id="status" class="btn btn-warning" value="Open">
                                        <input type="submit" value="Request E-Pin" class="btn btn-warning" >
                                    </div>      
                                    
                                </form>
                            </div>
                        </div>
                        <div class="footer">
                            <div class="chart-legend">
                                
                            </div>
                            <hr>
                            <div class="stats">
                                //
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Requested Status for E-pin</h4>
                        
                    </div>
                    <div class="content">
                            <div class="card table-responsive">
                                <table border="1" bordercolor="#ccc" class="table table-striped">
                                <tr class="">
                                    <th>#</th>
                                    <th>UserId</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                                <?php $__currentLoopData = $empinList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $pinres): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td><?php echo e($pinres->userid); ?></td>
                                    <td><?php echo e($pinres->amount); ?> </td>
                                    <td><?php echo e($pinres->status); ?> </td>
                                    <td><?php echo e(date('d-m-y', strtotime($pinres->created_at))); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                            <div><?php echo e($empinList->links()); ?></div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutes.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/epinOrder.blade.php ENDPATH**/ ?>