
<?php $__env->startSection('title'); ?>
    User Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="header">
                        <h4 class="title">My Downline </h4>
                        <p class="category">All Users List who have my Downline</p>
                    </div>
                    <div class="content">
                        
                        <ul>
                            <?php if(count($itemsres) > 0): ?>
                                <?php $__currentLoopData = $itemsres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li style="background:#ddd;padding:5px 10px;border:1px solid #fff;"><a href="<?php echo e('treeview'); ?>/<?php echo e($item->referralkey); ?>"><?php echo e($item->name); ?> </a>| <?php echo e($item->referralkey); ?></li>
                                    <ul>
                                        <?php if(count($item->childItems)): ?>
                                            <?php $__currentLoopData = $item->childItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo $__env->make('sub_items', ['sub_items' => $childItems], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card ">
                    <div class="header">
                        <h4 class="title">User Registration</h4>
                        <p class="category">You Can Add in Your downline From here</p>
                    </div>
                    <div class="content">
                        
                         <form action="<?php echo e(route('register.custom')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                                <input type="text" placeholder="Name" id="name" class="form-control" name="name"
                                    required autofocus>
                                <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                                <input type="hidden" placeholder="referralkey" id="referralkey" class="form-control" name="referralkey"
                                    value="<?php echo e(rand(000000,999999)); ?>">
                                <input type="text" placeholder="Sponserid" id="sponserid" class="form-control" name="sponserid"
                                    required autofocus>
                                <?php if($errors->has('sponserID')): ?>
                                <span class="text-danger"><?php echo e($errors->first('sponserid')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                                <input type="text" placeholder="Mobile Number" id="mobile" class="form-control" name="mobile"
                                    required autofocus>
                                <?php if($errors->has('mobile')): ?>
                                <span class="text-danger"><?php echo e($errors->first('mobile')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                                <input type="text" placeholder="Enter Amount" id="amount" class="form-control" name="amount"
                                    required autofocus>
                                <?php if($errors->has('amount')): ?>
                                <span class="text-danger"><?php echo e($errors->first('amount')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                                <input type="text" placeholder="Enter Epin" id="epin" class="form-control" name="epin"
                                    required autofocus>
                                <?php if($errors->has('amount')): ?>
                                <span class="text-danger"><?php echo e($errors->first('epin')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group mb-3">
                                <input type="text" placeholder="Email" id="email_address" class="form-control"
                                    name="email" required autofocus>
                                <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group mb-3">
                                <input type="password" placeholder="Password" id="password" class="form-control"
                                    name="password" required>
                                <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="d-grid mx-auto">
                                <button type="submit" class="btn btn-dark btn-block">Add User</button>
                            </div>
                            <br>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutes.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/users.blade.php ENDPATH**/ ?>