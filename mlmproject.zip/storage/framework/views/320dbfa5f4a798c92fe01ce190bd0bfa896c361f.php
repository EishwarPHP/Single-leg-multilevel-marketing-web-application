<footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <ul>

                <li>
                    <a href="">
                        Creative Tim
                    </a>
                </li>
                <li>
                    <a href="">
                       Blog
                    </a>
                </li>
                <li>
                    <a href="">
                        Licenses
                    </a>
                </li>
            </ul>
        </nav>
        <div class="copyright pull-right">
            © <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by <a href="">Kartcastle.com</a>
        </div>
    </div>
</footer>

<?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/layoutes/footer.blade.php ENDPATH**/ ?>