
<?php $__env->startSection('title'); ?>
    Level Setting
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card ">
                    <div class="header">
                        <h4 class="title">My E-Pin</h4>
                        <p class="category"><small>All Epin List Showing Here</small></p>
                    </div>
                    <div class="content">
                        <div class="card table-responsive">
                            <table border="1" bordercolor="#ccc" class="table table-striped">
                            <tr class="">
                                <th>#</th>
                                <th>UserId</th>
                                <th>E-Pin</th>
                                <th>Status</th>
                            </tr>
                            <?php $__currentLoopData = $allepinList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $pinlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i+1); ?></td>
                                <td><?php echo e($pinlist->user_id); ?></td>
                                <td><?php echo e($pinlist->pin); ?> </td>
                                <td><?php echo e($pinlist->status); ?> </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                        <div><?php echo e($allepinList->links()); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutes.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\KartCastle\mlmproject\resources\views/myepin.blade.php ENDPATH**/ ?>